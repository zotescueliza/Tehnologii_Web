const distance = (a, b) => {

	if (
		(typeof a !== 'string' && !(a instanceof String)) ||
		(typeof b !== 'string' && !(b instanceof String))
	) {
		throw { message: 'InvalidType' };
	}

	a = a.toString();
	b = b.toString();

	//daca ambele sunt striguri vide
	if (a.length === 0 && b.length === 0) return 0;

	const lenA = a.length;
	const lenB = b.length;

	const dp = Array.from({ length: lenA + 1 }, () => new Array(lenB + 1));
	
	//aici initializam matricea
	for (let i = 0; i <= lenA; i++) dp[i][0] = i;   //stergeri  
	for (let j = 0; j <= lenB; j++) dp[0][j] = j;   //inserari
	
	for (let i = 1; i <= lenA; i++) {
		for (let j = 1; j <= lenB; j++) {
			if (a[i - 1] === b[j - 1]) {
				dp[i][j] = dp[i - 1][j - 1];  // daca sunt identice => nu costa nimic
			} else {
				dp[i][j] = Math.min(
					dp[i - 1][j] + 1,     //delete
					dp[i][j - 1] + 1,     //insert
					dp[i - 1][j - 1] + 1  //inlocuim
				);
			}
		}
	}

	return dp[lenA][lenB];
};

module.exports.distance = distance;
